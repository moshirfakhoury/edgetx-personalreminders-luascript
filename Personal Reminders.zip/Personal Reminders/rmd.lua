local triggered = false

-------------------------------------------------
-- READ FILE
-------------------------------------------------

local function readAll()

  local f = io.open("/SCRIPTS/TOOLS/Reminders/data.txt","r")
  if not f then return nil end

  local buffer = ""
  local lines = {}

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "%D", "")

      if string.len(line) >= 8 then
        lines[#lines+1] = line
      end

    end

    if not chunk or chunk == "" then break end
  end

  io.close(f)
  return lines
end

-------------------------------------------------
-- MAIN
-------------------------------------------------

local function run()

  if triggered then return end

  local lines = readAll()
  if not lines then return end

  local now = getDateTime()
  local todayMonth = now.mon
  local todayDay = now.day

  local foundBirthday = false
  local foundReminder = false

  -------------------------------------------------
  -- SCAN ALL DATES
  -------------------------------------------------

  for i=1,#lines do

    local d = lines[i]

    local month = tonumber(string.sub(d,5,6))
    local day   = tonumber(string.sub(d,7,8))

    if month == todayMonth and day == todayDay then

      if i == 1 then
        foundBirthday = true
      else
        foundReminder = true
      end

      _G.reminderActive = true
    end

  end

  -------------------------------------------------
  -- PLAY SOUNDS
  -------------------------------------------------

  if foundBirthday then
    playFile("/SCRIPTS/TOOLS/Reminders/happybday.wav")
  end

  if foundReminder then
    playFile("/SCRIPTS/TOOLS/Reminders/reminder.wav")
  end

  if foundBirthday or foundReminder then
    triggered = true
  end

end

return { run = run }