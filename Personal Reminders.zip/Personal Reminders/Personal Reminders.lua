local toolName = "TNS|Personal Reminders|TNE"

-------------------------------------------------
-- PATH
-------------------------------------------------

local basePath = "/SCRIPTS/TOOLS/Reminders/"
local filePath = basePath .. "data.txt"
local bg = bitmap.open(basePath .. "background.png")

-------------------------------------------------
-- STATE
-------------------------------------------------

local page = 1
local hCursor = 1
local loaded = false
local message = ""

-- 7 DATE ENTRIES
local dates = {
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0},
  {0,0,0,0,0,0,0,0}
}

local labels = {
  "My Birthday",
  "Wedding Anniversary",
  "Wife Birthday",
  "Mom Birthday",
  "Dad Birthday",
  "Sister Birthday",
  "Brother Birthday"
}

-- 6 CUSTOM REMINDERS (TEXT + DATE)
local custom = {}

for i=1,6 do
  custom[i] = {
    text = {},
    date = {0,0,0,0,0,0,0,0}
  }

  for j=1,20 do
    custom[i].text[j] = " "
  end
end

local customLabels = {
  "Reminder 1",
  "Reminder 2",
  "Reminder 3",
  "Reminder 4",
  "Reminder 5",
  "Reminder 6"
}
-------------------------------------------------
-- HELPERS
-------------------------------------------------

local function digitsToDate(t)
  return string.format("%d%d%d%d%d%d%d%d",
    t[1],t[2],t[3],t[4],
    t[5],t[6],
    t[7],t[8]
  )
end

local function textToString(t)
  local s = ""
  for i=1,20 do s = s .. t[i] end
  return s
end

local function nextChar(c)
  local chars = " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  local i = string.find(chars, c, 1, true) or 1
  i = i % #chars + 1
  return string.sub(chars, i, i)
end

local function isToday(t, todayMonth, todayDay)

  local month = t[5] * 10 + t[6]
  local day   = t[7] * 10 + t[8]

  return (month == todayMonth and day == todayDay)
end

-------------------------------------------------
-- SAVE DATA
-------------------------------------------------

local function saveData()

  if not loaded then return end

  local f = io.open(filePath,"w")

  if f then

    -- PAGE 1
    for i=1,7 do
      io.write(f, digitsToDate(dates[i]) .. "\n")
    end

    -- PAGE 2
    for i=1,6 do
      io.write(f, textToString(custom[i].text) .. "\n")
      io.write(f, digitsToDate(custom[i].date) .. "\n")
    end

    io.close(f)
    message = "Saved"
  else
    message = "Save Failed"
  end
end

-------------------------------------------------
-- LOAD DATA
-------------------------------------------------

local function loadData()

  local f = io.open(filePath,"r")
  if not f then return end

  local buffer = ""
  local index = 1

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "\r", "")

      -------------------------------------------------
      -- PAGE 1 (first 7 lines)
      -------------------------------------------------
      if index <= 7 then

        local clean = string.gsub(line, "%D", "")

        if string.len(clean) >= 8 then
          for j=1,8 do
            dates[index][j] = tonumber(string.sub(clean, j, j))
          end
        end

      -------------------------------------------------
      -- PAGE 2 (text + date pairs)
      -------------------------------------------------
      else

        local i = math.floor((index-8)/2) + 1

        if i <= 6 then

          if (index-7) % 2 == 1 then
            -- TEXT LINE
            for j=1,20 do
              local c = string.sub(line, j, j)
              custom[i].text[j] = (c ~= "" and c) or " "
            end

          else
            -- DATE LINE
            local clean = string.gsub(line, "%D", "")

            if string.len(clean) >= 8 then
              for j=1,8 do
                custom[i].date[j] = tonumber(string.sub(clean, j, j))
              end
            end
          end

        end
      end

      index = index + 1

      if index > 19 then break end -- 7 + (6×2)
    end

    if index > 19 then break end
    if not chunk or chunk == "" then break end

  end

  io.close(f)
end

-------------------------------------------------
-- READ SAVED (VIEW PAGE)
-------------------------------------------------

local function readSavedDates()

  local f = io.open(filePath, "r")
  if not f then return nil end

  local buffer = ""
  local saved = {}
  local index = 1

  while true do

    local chunk = io.read(f, 128)

    if not chunk or chunk == "" then
      buffer = buffer .. "\n"
    else
      buffer = buffer .. chunk
    end

    while true do

      local s = string.find(buffer, "\n", 1, true)
      if not s then break end

      local line = string.sub(buffer, 1, s-1)
      buffer = string.sub(buffer, s+1)

      line = string.gsub(line, "\r", "")

      if index <= 7 then
        local clean = string.gsub(line, "%D", "")
        saved[index] = (string.len(clean) >= 8) and clean or "--------"

      else
        if (index - 7) % 2 == 1 then
          saved[index] = line ~= "" and line or "--------------------"
        else
          local clean = string.gsub(line, "%D", "")
          saved[index] = (string.len(clean) >= 8) and clean or "--------"
        end
      end

      index = index + 1
      if index > 19 then break end

    end

    if index > 19 then break end
    if not chunk or chunk == "" then break end

  end

  io.close(f)

  return saved
end

-------------------------------------------------
-- DRAW HELPERS
-------------------------------------------------

local function drawDateRow(y,label,t,offset)
  lcd.drawText(40,y,label)

  local x = 250
  for i=1,8 do
    lcd.drawText(
      x + (i-1)*12,
      y,
      tostring(t[i]),
      (hCursor == offset+i-1) and INVERS or 0
    )
  end
end

-------------------------------------------------
-- MAIN
-------------------------------------------------

local function run(event)

  local now = getDateTime()
  local todayMonth = now.mon
  local todayDay = now.day

  local flash = (getTime() % 100) < 50
  
  if not loaded then
    loadData()
    loaded = true
  end

  if bg then
    lcd.drawBitmap(bg, 0, 0)
  else
    lcd.clear()
  end

-------------------------------------------------
-- PAGE 1 : MAIN VIEW
-------------------------------------------------

if page == 1 then

  lcd.drawText(LCD_W/2,5,"Saved Reminders",DBLSIZE + CENTER + DARKBROWN)

  local saved = readSavedDates()
  local y = 70
  local s = 25

  for i=1,7 do
    lcd.drawText(40, y + s*(i-1), labels[i])
    lcd.drawText(250, y + s*(i-1), saved and saved[i] or "--------")
    
    if isToday(dates[i], todayMonth, todayDay) and flash then
      lcd.drawFilledCircle(20, y + s*(i-1) + 9, 5, GREEN)
    end
  end

  -- buttons
  lcd.drawText(40, y + s*8 -22, "Next Page", hCursor==1 and INVERS or 0)
  lcd.drawText(200, y + s*8 -22, "Previous Page", hCursor==2 and INVERS or 0)

  lcd.drawText(LCD_W-70,250,"Page 1/4",SMLSIZE)

  -------------------------------------------------
  if event==EVT_VIRTUAL_NEXT then hCursor=hCursor%2+1 end
  if event==EVT_VIRTUAL_PREV then hCursor=(hCursor-2)%2+1 end

  if event==EVT_VIRTUAL_ENTER then

    if hCursor == 1 then
      page = 2
      hCursor = 1
      return 0

    elseif hCursor == 2 then
      page = 4
      hCursor = 1
      return 0
    end

  end

end

-------------------------------------------------
-- PAGE 2 : CUSTOM REMINDERS VIEW
-------------------------------------------------

if page == 2 then

  lcd.drawText(LCD_W/2,5,"Saved Reminders",DBLSIZE + CENTER + DARKBROWN)

  local saved = readSavedDates()

  local y = 70
  local s = 25

  local index = 8 -- custom data starts here

  for i=1,6 do

    local text = saved and saved[index] or "--------------------"
    local date = saved and saved[index+1] or "--------"

    lcd.drawText(40, y + s*(i-1), text)
    lcd.drawText(300, y + s*(i-1), date)
    
    if isToday(custom[i].date, todayMonth, todayDay) and flash then
      lcd.drawFilledCircle(20, y + s*(i-1) + 9, 5, GREEN)
    end
    index = index + 2
  end

  -------------------------------------------------
  -- BUTTON
  -------------------------------------------------

  lcd.drawText(40, y + s*8 -22, "Next Page", hCursor==1 and INVERS or 0)
  lcd.drawText(200, y + s*8 -22, "Previous Page", hCursor==2 and INVERS or 0)

  lcd.drawText(LCD_W-70,250,"Page 2/4",SMLSIZE)

  -------------------------------------------------
  -- NAVIGATION
  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then hCursor=hCursor%2+1 end
  if event==EVT_VIRTUAL_PREV then hCursor=(hCursor-2)%2+1 end

  -------------------------------------------------
  -- ENTER
  -------------------------------------------------

  if event==EVT_VIRTUAL_ENTER then

    if hCursor == 1 then
      page = 3
      hCursor = 1
      return 0

    elseif hCursor == 2 then
      page = 1
      hCursor = 1
      return 0
    end

  end

end
-------------------------------------------------
-- PAGE 3 : REMINDER SETUP
-------------------------------------------------

if page == 3 then

  lcd.drawText(LCD_W/2,5,"Reminder Setup",DBLSIZE + CENTER + DARKBROWN)

  local y = 70
  local s = 25

  -- rows
  for i=1,7 do
    drawDateRow(y + s*(i-1), labels[i], dates[i], (i-1)*8 + 1)
  end

  -- helper text
  local fx = LCD_W - 105   
  local fy = LCD_H/2 - 15          
  lcd.drawText(fx, fy, "Date Format:", SMLSIZE + DARKBROWN)
  lcd.drawText(fx, fy + 15, "YYYYMMDD", SMLSIZE + DARKBROWN)

  -- buttons
  lcd.drawText(40, y + s*8 - 20, "Save", hCursor==57 and INVERS or 0)
  lcd.drawText(200, y + s*8 - 20, "Next Page", hCursor==58 and INVERS or 0)

  lcd.drawText(90,250,message,SMLSIZE + DARKBROWN)
  lcd.drawText(LCD_W-70,250,"Page 3/4",SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then hCursor=hCursor%58+1 end
  if event==EVT_VIRTUAL_PREV then hCursor=(hCursor-2)%58+1 end

  if event==EVT_VIRTUAL_ENTER then

    if hCursor <= 56 then
      local row = math.floor((hCursor-1)/8) + 1
      local col = ((hCursor-1)%8) + 1
      dates[row][col] = (dates[row][col] + 1) % 10

    elseif hCursor == 57 then
      saveData()

    elseif hCursor == 58 then
      page = 4
      hCursor = 1
      return 0
    end
  end
end

-------------------------------------------------
-- PAGE 4 : CUSTOM REMINDERS
-------------------------------------------------

if page == 4 then

  lcd.drawText(LCD_W/2,5,"Custom Reminders",DBLSIZE + CENTER + DARKBROWN)

  local y = 70
  local s = 25

  for i=1,6 do

    lcd.drawText(40, y + s*(i-1), customLabels[i])

    -- TEXT
    for j=1,20 do
      lcd.drawText(
        180 + (j-1)*8,
        y + s*(i-1),
        custom[i].text[j],
        (hCursor == ((i-1)*28 + j)) and INVERS or 0
      )
    end

    -- DATE
    for j=1,8 do
      lcd.drawText(
        360 + (j-1)*12,
        y + s*(i-1),
        tostring(custom[i].date[j]),
        (hCursor == ((i-1)*28 + 20 + j)) and INVERS or 0
      )
    end

  end

  lcd.drawText(40, y + s*7, "Next Page", hCursor==169 and INVERS or 0)
  lcd.drawText(200, y + s*7, "Previous Page", hCursor==170 and INVERS or 0)

  lcd.drawText(LCD_W-70,250,"Page 4/4",SMLSIZE)

  -------------------------------------------------

  if event==EVT_VIRTUAL_NEXT then hCursor=hCursor%170+1 end
  if event==EVT_VIRTUAL_PREV then hCursor=(hCursor-2)%170+1 end

  if event==EVT_VIRTUAL_ENTER then

    if hCursor <= 168 then

      local row = math.floor((hCursor-1)/28) + 1
      local pos = ((hCursor-1)%28) + 1

      if pos <= 20 then
        custom[row].text[pos] = nextChar(custom[row].text[pos])
      else
        local d = pos - 20
        custom[row].date[d] = (custom[row].date[d] + 1) % 10
      end

    elseif hCursor == 169 then
      page = 1
      hCursor = 1
      return 0

    elseif hCursor == 170 then
      page = 3
      hCursor = 1
      return 0
    end
  end

end

-------------------------------------------------

  return 0
end

return { run=run }